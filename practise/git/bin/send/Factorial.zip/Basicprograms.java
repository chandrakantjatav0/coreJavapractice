package send;
//print numbers 1 to 10
public class Basicprograms {

	public static void main(String[] args) {
		for(int i =1; i <=10; i++)
			System.out.println(i);
	}

}